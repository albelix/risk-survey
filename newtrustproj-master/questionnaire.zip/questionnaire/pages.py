from otree.api import Currency as c, currency_range
from ._builtin import Page, WaitPage
from .models import Constants


# from otreeutils.surveys import SurveyPage
#
# class SurveyPage1(SurveyPage):
#     pass
#
# from otreeutils.surveys import setup_survey_pages
#
# survey_pages = [
#     SurveyPage1
# ]
#
# setup_survey_pages(Player, survey_pages)   # Player from "models"

class Motivation(Page):
    form_model = 'player'
    form_fields = ['motivation_part1',
               'motivation_part2',
                  ]


class Personal1(Page):
    form_model = 'player'
    form_fields = ['age',
               'gender',
               'field',
               'field_other',
               'degree',
               'degree_other',
               'gender',
               'age',
               'birthplace',
               'GPA',
               'marital_status',
               'language',
               'language_other',
               'living',
               'living_other',
               'city'
               ]


class SelfDetermination(Page):
    form_model = 'player'
    form_fields = [
            'nationality',
            'religion',
            'religion_other',
            'religion_moral',
            'religion_service',
            'community_local',
            'community_russian'
             ]

class Trust(Page):
    form_model = 'player'
    form_fields = [
            'trust',
        #    'catrust',
            'trust_family',
            'trust_neighbours',
            'trust_acquant',
            'trust_stranger',
            'trust_other_faith',
            'trust_fiends',
            'trust_politicians',
       #     'catrust_institutions',
            'trust_church',
            'trust_army',
            'trust_press',
            'trust_tv',
            'trust_tradeunion',
            'trust_police',
            'trust_courts',
            'trust_government',
            'trust_parties',
            'trust_president',
            'trust_parliament',
            'trust_regional_authorities',
            'trust_local_authorities',
            'trust_charity',
            'trust_CIS',
            'trust_UN',
            'dreadyhelp'
            ]

class Values(Page):
        form_model = 'player'
        form_fields = [
            'similar_newideas',
            'similar_wealthy',
            'similar_safety',
            'similar_hedonic',
            'similar_renowned',
            'similar_adventurous',
            'similar_correct',
            'similar_care_environment',
            'similar_tradition'
            ]

class Risk(Page):
            form_model = 'player'
            form_fields = [
            'riskat',
        #    'catrisk',
            'riskfin',
            'risksport',
            'riskprof',
            'riskhealth',
            'riskstran'
             ]

class StatedPreferences(Page):
    form_model = 'player'
    form_fields = [
        'positive_reciprocity',
        'negative_reciprocity',
        'abuse_you',
        'fairness_russian',
        'fairness_general',
        'competition',
        'separation_power',
        'independent_judiciary',
        'corruption',
        'civil_rights'
    ]

class Region(Page):
        form_model = 'player'
        form_fields = [
            'Ark_been',
            'Vlk_been',
            'Vor_been',
            'Ekb_been',
            'Kaz_been',
            'Mak_been',
            'Mos_been',
            'Nsk_been',
            'Per_been',
            'Ros_been',
            'SPb_been',
            'Khb_been',
            'abroad_been',
            'Ark_source',
            'Vlk_source',
            'Vor_source',
            'Ekb_source',
            'Kaz_source',
            'Mak_source',
            'Mos_source',
            'Nsk_source',
            'Per_source',
            'Ros_source',
            'SPb_source',
            'Khb_source',
            'Ark_rank',
            'Vlk_rank',
            'Vor_rank',
            'Ekb_rank',
            'Kaz_rank',
            'Mak_rank',
            'Mos_rank',
            'Nsk_rank',
            'Per_rank',
            'Ros_rank',
            'SPb_rank',
            'Khb_rank',
            'regional_income',
            'regional_differences'
        ]


class Personal2(Page):
    form_model = 'player'
    form_fields = [
                'satis',
                'happy',
                'happy_relative',
                'income',
               ]

page_sequence = [Motivation, Personal1, SelfDetermination, Trust, Values, Risk, StatedPreferences, Region, Personal2]


